import { create } from "zustand";
import { Part } from "../types";

interface CartItem extends Part {
  quantity: number;
}

interface CartState {
  items: CartItem[];
  addToCart: (item: Part) => void;
  removeFromCart: (id: string) => void;
  clearCart: () => void;
  totalItems: number;
}

export const useCartStore = create<CartState>((set, get) => ({
  items: [],
  addToCart: (item: Part) => {
    const existingItem = get().items.find((i) => i.id === item.id);
    if (existingItem) {
      set({
        items: get().items.map((i) =>
          i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
        ),
      });
    } else {
      set({ items: [...get().items, { ...item, quantity: 1 }] });
    }
  },
  removeFromCart: (id: string) => {
    set({ items: get().items.filter((item) => item.id !== id) });
  },
  decreaseQuantity: (id: string) => {
    const existingItem = get().items.find((item) => item.id === id);
    if (!existingItem) return;
    if (existingItem.quantity === 1) {
      set({ items: get().items.filter((item) => item.id !== id) });
    } else {
      set({
        items: get().items.map((item) =>
          item.id === id ? { ...item, quantity: item.quantity - 1 } : item
        ),
      });
    }
  },
  
  clearCart: () => {
    set({ items: [] });
  },
  get totalItems() {
    return get().items.reduce((sum, item) => sum + item.quantity, 0);
  },
}));
