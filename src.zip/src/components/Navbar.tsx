import React from "react";
import { Link } from "react-router-dom";
import { FaShoppingCart, FaSun, FaMoon, FaTools } from "react-icons/fa";
import { useCartStore } from "../store/cartStore";

interface NavbarProps {
  darkMode: boolean;
  toggleDarkMode: () => void;
  navVisible: boolean;
}

const Navbar: React.FC<NavbarProps> = ({ darkMode, toggleDarkMode, navVisible }) => {
  const totalItems = useCartStore((state) => state.totalItems);

  const scrollToHero = () => {
    const heroElement = document.getElementById("hero");
    if (heroElement) {
      heroElement.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <nav
      className={`fixed top-4 left-4 right-4 z-50 shadow-md transition-transform duration-300 ${
        navVisible ? "translate-y-0" : "-translate-y-full"
      } bg-gradient-to-r from-red-500 via-blue-500 to-purple-600 rounded-xl`}
    >
      <div className="flex justify-between items-center p-4 px-6 text-white">
        <div className="flex items-center gap-2">
          <FaTools className="text-white text-xl" />
          <Link to="/" className="text-2xl font-bold tracking-tight uppercase">
            <span className="text-red-300">Smart</span>
            <span className="text-blue-200">Fix</span>
          </Link>
        </div>
        <div className="flex gap-6 items-center">
          
          <Link to="/sell-phone" className="hover:text-gray-300">Продай телефон</Link>
          <Link to="/services" className="hover:text-gray-300">Услуги</Link>
          <Link to="/parts" className="hover:text-gray-300">Части</Link>
          <Link to="/contact" className="hover:text-gray-300">Контакти</Link>
          <Link to="/cart" className="relative">
            <FaShoppingCart className="h-6 w-6" />
            {totalItems > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">
                {totalItems}
              </span>
            )}
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
