import React from "react";

interface FooterProps {
  darkMode: boolean;
}

const Footer: React.FC<FooterProps> = ({ darkMode }) => (
  <footer className={`${darkMode ? "bg-gray-900 text-white" : "bg-gray-100 text-black"} text-center py-6`}>
    <p>© 2024 SmartFix. Всички права запазени.</p>
  </footer>
);

export default Footer;
