import React from "react";

const BookingPage = () => <div className="p-4 text-xl">Форма за записване на час ще бъде тук.</div>;

export default BookingPage;
