import React from "react";
import Services from "../components/Services";

const ServicesPage = () => <Services />;

export default ServicesPage;
