import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useCartStore } from "../store/cartStore";

const Checkout: React.FC = () => {
  const navigate = useNavigate();
  const items = useCartStore((state) => state.items);
  const clearCart = useCartStore((state) => state.clearCart);
  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    paymentMethod: "cash",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      // ✅ Always store the order
      const saveRes = await fetch("http://localhost:5000/create-order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, items, total }),
      });

      if (!saveRes.ok) throw new Error("Неуспешно създаване на поръчка");

      // ✅ Card: redirect to Stripe checkout
      if (form.paymentMethod === "card") {
        const stripeRes = await fetch("http://localhost:5000/create-checkout-session", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ items }),
        });

        const data = await stripeRes.json();
        if (data.url) {
          clearCart();
          window.location.href = data.url;
        } else {
          alert("⚠️ Проблем със Stripe.");
        }
        return;
      }

      // ✅ Cash: local success
      clearCart();
      navigate("/success");
    } catch (error) {
      console.error("Order error:", error);
      alert("⚠️ Грешка при изпращане на поръчка.");
    }
  };

  return (
    <div className="min-h-screen bg-black text-white py-10 px-4">
      <div className="max-w-2xl mx-auto bg-gray-900 p-6 rounded-lg shadow-md">
        <h2 className="text-3xl font-bold mb-6 text-center">Завършване на поръчка</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            name="name"
            placeholder="Име и фамилия"
            value={form.name}
            onChange={handleChange}
            className="w-full p-3 rounded bg-gray-800 text-white"
            required
          />
          <input
            name="email"
            placeholder="Имейл"
            type="email"
            value={form.email}
            onChange={handleChange}
            className="w-full p-3 rounded bg-gray-800 text-white"
            required
          />
          <input
            name="phone"
            placeholder="Телефон"
            value={form.phone}
            onChange={handleChange}
            className="w-full p-3 rounded bg-gray-800 text-white"
            required
          />
          <input
            name="address"
            placeholder="Адрес за доставка"
            value={form.address}
            onChange={handleChange}
            className="w-full p-3 rounded bg-gray-800 text-white"
          />
          <select
            name="paymentMethod"
            value={form.paymentMethod}
            onChange={handleChange}
            className="w-full p-3 rounded bg-gray-800 text-white"
          >
            <option value="cash">Наложен платеж</option>
            <option value="card">Плащане с карта</option>
          </select>

          {/* ✅ Order Summary */}
          <div className="bg-gray-200 text-black rounded p-4 mt-4">
            <h4 className="font-bold text-lg mb-2 text-purple-700">Преглед на поръчката:</h4>
            <ul className="text-sm text-gray-700">
              {items.map((item) => (
                <li key={item.id}>
                  {item.name} × {item.quantity} = {item.price * item.quantity} лв.
                </li>
              ))}
            </ul>
            <p className="font-bold mt-2">Общо: {total.toFixed(2)} лв.</p>
          </div>

          <button
            type="submit"
            className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-6 rounded transition"
          >
            Потвърди поръчката
          </button>
        </form>
      </div>
    </div>
  );
};

export default Checkout;
